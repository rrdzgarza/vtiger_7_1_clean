Use this directory to store your .docx templates.
The system will scan this folder and populate the selection dropdown.
Example variables: ${subject}, ${quote_no}, ${accountname}.
Example table row variables: ${product_name}, ${product_qty}, ${product_price}.
